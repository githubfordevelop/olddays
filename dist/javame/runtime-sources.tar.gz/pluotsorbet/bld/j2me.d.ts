/// <reference path="../tools/lib.d.ts" />
/// <reference path="../tools/es6-promises.d.ts" />
/** @const */ declare var release: boolean;
/** @const */ declare var profile: number;
/** @const */ declare var profileFormat: string;
/** @const */ declare var asmJsTotalMemory: number;
declare var pc2line: any;
declare var jsGlobal: any;
declare var inBrowser: boolean;
declare var flagsOf: any;
declare var putstr: any;
declare var printErr: any;
declare var dateNow: () => number;
interface String {
    padRight(c: string, n: number): string;
    padLeft(c: string, n: number): string;
    endsWith(s: string): boolean;
}
interface Math {
    imul(a: number, b: number): number;
    /**
     * Returns the number of leading zeros of a number.
     * @param x A numeric expression.
     */
    clz32(x: number): number;
}
interface Error {
    stack: string;
}
declare module J2ME {
    function isIdentifierStart(c: any): boolean;
    function isIdentifierPart(c: any): boolean;
    function isIdentifierName(s: any): boolean;
    function isObject(value: any): boolean;
    function isNullOrUndefined(value: any): boolean;
    module Debug {
        function error(message: string): void;
        function assert(condition: any, message: string): void;
        function assertUnreachable(msg: string): void;
        function abstractMethod(message: string): void;
        /**
         * Ensures that the object is not in dictionary mode. To use this, you'll need a
         * special build of SpiderMonkey, ask mbx.
         */
        function assertNonDictionaryModeObject(object: Object): void;
        function unexpected(message?: any): void;
    }
    function getTicks(): number;
    module ArrayUtilities {
        var EMPTY_ARRAY: any[];
        function makeArrays(length: number): any[][];
        /**
         * Pops elements from a source array into a destination array. This avoids
         * allocations and should be faster. The elements in the destination array
         * are pushed in the same order as they appear in the source array:
         *
         * popManyInto([1, 2, 3], 2, dst) => dst = [2, 3]
         */
        function popManyInto(src: any[], count: number, dst: any[]): void;
        function pushMany(dst: any[], src: any[]): void;
        function pushUnique<T>(array: T[], value: T): number;
        function unique<T>(array: T[]): T[];
        /**
         * You'd hope that new Array() triggers different heuristics about how and when it should fall back
         * to dictionary mode. I've experienced ION bailouts from non-dense new Arrays(), hence this helper
         * method.
         */
        function makeDenseArray(length: number, value: any): any[];
        /**
         * Resizes a Int32Array to have the given length.
         */
        function ensureInt32ArrayLength(array: Int32Array, length: number): Int32Array;
    }
    module ObjectUtilities {
        function createMap<K, V>(): Map<K, V>;
    }
    module FunctionUtilities {
        function makeForwardingGetter(target: string): () => any;
        function makeForwardingSetter(target: string): (any) => void;
        function makeDebugForwardingSetter(target: string, checker: (l: any, h: number) => boolean): (any) => void;
    }
    module StringUtilities {
        /**
         * Returns a reasonably sized description of the |value|, to be used for debugging purposes.
         */
        function toSafeString(value: any): string;
        function escapeString(str: string): string;
        function quote(s: string): string;
        function variableLengthEncodeInt32(n: any): string;
        function toEncoding(n: any): string;
        /**
         * The concatN() functions concatenate multiple strings in a way that
         * avoids creating intermediate strings, unlike String.prototype.concat().
         *
         * Note that these functions don't have identical behaviour to using '+',
         * because they will ignore any arguments that are |undefined| or |null|.
         * This usually doesn't matter.
         */
        function concat3(s0: any, s1: any, s2: any): string;
    }
    module HashUtilities {
        function hashBytesTo32BitsMurmur(data: Uint8Array, offset: number, length: number): number;
        function hashBytesTo32BitsAdler(data: Uint8Array, offset: number, length: number): number;
    }
    const enum Numbers {
        MaxU16 = 65535,
        MaxI16 = 32767,
        MinI16 = -32768,
    }
    module IntegerUtilities {
        var i32: Int32Array;
        var f32: Float32Array;
        var f64: Float64Array;
        function bitCount(i: number): number;
        function ones(i: number): number;
        function toHEX(i: number): string;
    }
    const enum LogLevel {
        Error = 1,
        Warn = 2,
        Debug = 4,
        Log = 8,
        Info = 16,
        All = 31,
    }
    class IndentingWriter {
        static PURPLE: string;
        static YELLOW: string;
        static GREEN: string;
        static RED: string;
        static BOLD_RED: string;
        static ENDC: string;
        static logLevel: LogLevel;
        static stdout: any;
        static stdoutNoNewline: any;
        static stderr: any;
        private _tab;
        private _padding;
        private _suppressOutput;
        private _out;
        private _outNoNewline;
        constructor(suppressOutput?: boolean, out?: any);
        write(str?: string, writePadding?: boolean): void;
        writeLn(str?: string): void;
        writeTimeLn(str?: string): void;
        writeComment(str: string): void;
        writeLns(str: string): void;
        errorLn(str: string): void;
        warnLn(str: string): void;
        debugLn(str: string): void;
        logLn(str: string): void;
        infoLn(str: string): void;
        yellowLn(str: string): void;
        greenLn(str: string): void;
        boldRedLn(str: string): void;
        redLn(str: string): void;
        purpleLn(str: string): void;
        colorLn(color: string, str: string): void;
        redLns(str: string): void;
        colorLns(color: string, str: string): void;
        enter(str: string): void;
        leaveAndEnter(str: string): void;
        leave(str: string): void;
        indent(): void;
        outdent(): void;
        writeArray(arr: any[], detailed?: boolean, noNumbers?: boolean): void;
    }
    module BitSets {
        var ADDRESS_BITS_PER_WORD: number;
        var BITS_PER_WORD: number;
        var BIT_INDEX_MASK: number;
        interface BitSet {
            set: (i) => void;
            setAll: () => void;
            assign: (set: BitSet) => void;
            clear: (i: number) => void;
            get: (i: number) => boolean;
            clearAll: () => void;
            intersect: (other: BitSet) => void;
            subtract: (other: BitSet) => void;
            negate: () => void;
            forEach: (fn) => void;
            toArray: () => boolean[];
            equals: (other: BitSet) => boolean;
            contains: (other: BitSet) => boolean;
            isEmpty: () => boolean;
            clone: () => BitSet;
            recount: () => void;
            toString: (names: string[]) => string;
            toBitString: (on: string, off: string) => string;
        }
        class Uint32ArrayBitSet implements BitSet {
            size: number;
            bits: Uint32Array;
            count: number;
            dirty: number;
            length: number;
            constructor(length: number);
            recount(): void;
            set(i: any): void;
            setAll(): void;
            assign(set: any): void;
            nextSetBit(from: number, to: number): number;
            clear(i: any): void;
            get(i: any): boolean;
            clearAll(): void;
            private _union(other);
            intersect(other: Uint32ArrayBitSet): void;
            subtract(other: Uint32ArrayBitSet): void;
            negate(): void;
            forEach(fn: any): void;
            toArray(): boolean[];
            equals(other: Uint32ArrayBitSet): boolean;
            contains(other: Uint32ArrayBitSet): boolean;
            toBitString: (on: string, off: string) => string;
            toString: (names: string[]) => string;
            isEmpty(): boolean;
            clone(): Uint32ArrayBitSet;
        }
    }
    function parseManifest(fileContents: string): any;
}
declare module J2ME.Shell {
    class MicroTask {
        id: number;
        fn: () => any;
        args: any[];
        interval: number;
        repeat: boolean;
        runAt: number;
        constructor(id: number, fn: () => any, args: any[], interval: number, repeat: boolean);
    }
    class MicroTasksQueue {
        private tasks;
        private nextId;
        private stopped;
        constructor();
        isEmpty: boolean;
        scheduleInterval(fn: () => any, args: any[], interval: number, repeat: boolean): MicroTask;
        enqueue(task: MicroTask): void;
        dequeue(runAt: number): MicroTask;
        remove(id: number): void;
        clear(): void;
        /**
         * Runs micro tasks for a certain |duration| and |count| whichever comes first. Optionally,
         * if the |clear| option is specified, the micro task queue is cleared even if not all the
         * tasks have been executed.
         *
         * If a |preCallback| function is specified, only continue execution if |preCallback()| returns true.
         */
        run(duration?: number, count?: number, clear?: boolean, preCallback?: Function): void;
        stop(): void;
    }
}
declare module J2ME.Metrics {
    class Timer {
        private static _base;
        private static _top;
        private static _flat;
        private static _flatStack;
        private _parent;
        private _name;
        private _begin;
        private _last;
        private _total;
        private _count;
        private _timers;
        constructor(parent: Timer, name: string);
        static time(name: any, fn: Function): void;
        static start(name: any): void;
        static stop(): void;
        static stopStart(name: any): void;
        start(): void;
        stop(): void;
        toJSON(): {
            name: string;
            total: number;
            timers: Map<string, Timer>;
        };
        trace(writer: IndentingWriter): void;
        static trace(writer: IndentingWriter): void;
    }
    /**
     * Quick way to count named events.
     */
    class Counter {
        static instance: Counter;
        private _enabled;
        private _counts;
        private _times;
        counts: Map<string, number>;
        constructor(enabled: boolean);
        setEnabled(enabled: boolean): void;
        clear(): void;
        toJSON(): {
            counts: Map<string, number>;
            times: Map<string, number>;
        };
        count(name: string, increment?: number, time?: number): any;
        trace(writer: IndentingWriter): void;
        private _pairToString(times, pair);
        toStringSorted(): string;
        traceSorted(writer: IndentingWriter, inline?: boolean): void;
    }
    class Average {
        private _samples;
        private _count;
        private _index;
        constructor(max: any);
        push(sample: number): void;
        average(): number;
    }
}
/**
 * Port of Java java.util.Hashtable.
 */
declare module J2ME {
    class TypedArrayHashtableEntry {
        hash: number;
        value: any;
        next: TypedArrayHashtableEntry;
        key: Uint8Array;
    }
    class TypedArrayHashtable {
        table: TypedArrayHashtableEntry[];
        count: number;
        private threshold;
        private static loadFactorPercent;
        constructor(initialCapacity: number);
        contains(key: Uint8Array): boolean;
        getByRange(key: Uint8Array, offset: number, length: number): any;
        get(key: Uint8Array): any;
        put(key: Uint8Array, value: any): any;
        rehash(): void;
    }
}
declare module J2ME.Bytecode {
    class Bytes {
        /**
         * Gets a signed 1-byte value.
         */
        static beS1(data: Uint8Array, bci: number): number;
        /**
         * Gets a signed 2-byte big-endian value.
         */
        static beS2(data: Uint8Array, bci: number): number;
        /**
         * Gets an unsigned 1-byte value.
         */
        static beU1(data: Uint8Array, bci: number): number;
        /**
         * Gets an unsigned 2-byte big-endian value.
         */
        static beU2(data: Uint8Array, bci: number): number;
        /**
         * Gets a signed 4-byte big-endian value.
         */
        static beS4(data: Uint8Array, bci: number): number;
        /**
         * Gets either a signed 2-byte or a signed 4-byte big-endian value.
         */
        static beSVar(data: Uint8Array, bci: number, fourByte: boolean): number;
    }
    const enum Condition {
        /**
         * Equal.
         */
        EQ = 0,
        /**
         * Not equal.
         */
        NE = 1,
        /**
         * Signed less than.
         */
        LT = 2,
        /**
         * Signed less than or equal.
         */
        LE = 3,
        /**
         * Signed greater than.
         */
        GT = 4,
        /**
         * Signed greater than or equal.
         */
        GE = 5,
        /**
         * Unsigned greater than or equal ("above than or equal").
         */
        AE = 6,
        /**
         * Unsigned less than or equal ("below than or equal").
         */
        BE = 7,
        /**
         * Unsigned greater than ("above than").
         */
        AT = 8,
        /**
         * Unsigned less than ("below than").
         */
        BT = 9,
        /**
         * Operation produced an overflow.
         */
        OF = 10,
        /**
         * Operation did not produce an overflow.
         */
        NOF = 11,
    }
    /**
     * The definitions of the bytecodes that are valid input to the compiler and
     * related utility methods. This comprises two groups: the standard Java
     * bytecodes defined by <a href=
     * "http://java.sun.com/docs/books/jvms/second_edition/html/VMSpecTOC.doc.html">
     * Java Virtual Machine Specification</a>, and a set of <i>extended</i>
     * bytecodes that support low-level programming, for example, memory barriers.
     *
     * The extended bytecodes are one or three bytes in size. The one-byte bytecodes
     * follow the values in the standard set, with no gap. The three-byte extended
     * bytecodes share a common first byte and carry additional instruction-specific
     * information in the second and third bytes.
     */
    const enum Bytecodes {
        NOP = 0,
        ACONST_NULL = 1,
        ICONST_M1 = 2,
        ICONST_0 = 3,
        ICONST_1 = 4,
        ICONST_2 = 5,
        ICONST_3 = 6,
        ICONST_4 = 7,
        ICONST_5 = 8,
        LCONST_0 = 9,
        LCONST_1 = 10,
        FCONST_0 = 11,
        FCONST_1 = 12,
        FCONST_2 = 13,
        DCONST_0 = 14,
        DCONST_1 = 15,
        BIPUSH = 16,
        SIPUSH = 17,
        LDC = 18,
        LDC_W = 19,
        LDC2_W = 20,
        ILOAD = 21,
        LLOAD = 22,
        FLOAD = 23,
        DLOAD = 24,
        ALOAD = 25,
        ILOAD_0 = 26,
        ILOAD_1 = 27,
        ILOAD_2 = 28,
        ILOAD_3 = 29,
        LLOAD_0 = 30,
        LLOAD_1 = 31,
        LLOAD_2 = 32,
        LLOAD_3 = 33,
        FLOAD_0 = 34,
        FLOAD_1 = 35,
        FLOAD_2 = 36,
        FLOAD_3 = 37,
        DLOAD_0 = 38,
        DLOAD_1 = 39,
        DLOAD_2 = 40,
        DLOAD_3 = 41,
        ALOAD_0 = 42,
        ALOAD_1 = 43,
        ALOAD_2 = 44,
        ALOAD_3 = 45,
        IALOAD = 46,
        LALOAD = 47,
        FALOAD = 48,
        DALOAD = 49,
        AALOAD = 50,
        BALOAD = 51,
        CALOAD = 52,
        SALOAD = 53,
        ISTORE = 54,
        LSTORE = 55,
        FSTORE = 56,
        DSTORE = 57,
        ASTORE = 58,
        ISTORE_0 = 59,
        ISTORE_1 = 60,
        ISTORE_2 = 61,
        ISTORE_3 = 62,
        LSTORE_0 = 63,
        LSTORE_1 = 64,
        LSTORE_2 = 65,
        LSTORE_3 = 66,
        FSTORE_0 = 67,
        FSTORE_1 = 68,
        FSTORE_2 = 69,
        FSTORE_3 = 70,
        DSTORE_0 = 71,
        DSTORE_1 = 72,
        DSTORE_2 = 73,
        DSTORE_3 = 74,
        ASTORE_0 = 75,
        ASTORE_1 = 76,
        ASTORE_2 = 77,
        ASTORE_3 = 78,
        IASTORE = 79,
        LASTORE = 80,
        FASTORE = 81,
        DASTORE = 82,
        AASTORE = 83,
        BASTORE = 84,
        CASTORE = 85,
        SASTORE = 86,
        POP = 87,
        POP2 = 88,
        DUP = 89,
        DUP_X1 = 90,
        DUP_X2 = 91,
        DUP2 = 92,
        DUP2_X1 = 93,
        DUP2_X2 = 94,
        SWAP = 95,
        IADD = 96,
        LADD = 97,
        FADD = 98,
        DADD = 99,
        ISUB = 100,
        LSUB = 101,
        FSUB = 102,
        DSUB = 103,
        IMUL = 104,
        LMUL = 105,
        FMUL = 106,
        DMUL = 107,
        IDIV = 108,
        LDIV = 109,
        FDIV = 110,
        DDIV = 111,
        IREM = 112,
        LREM = 113,
        FREM = 114,
        DREM = 115,
        INEG = 116,
        LNEG = 117,
        FNEG = 118,
        DNEG = 119,
        ISHL = 120,
        LSHL = 121,
        ISHR = 122,
        LSHR = 123,
        IUSHR = 124,
        LUSHR = 125,
        IAND = 126,
        LAND = 127,
        IOR = 128,
        LOR = 129,
        IXOR = 130,
        LXOR = 131,
        IINC = 132,
        I2L = 133,
        I2F = 134,
        I2D = 135,
        L2I = 136,
        L2F = 137,
        L2D = 138,
        F2I = 139,
        F2L = 140,
        F2D = 141,
        D2I = 142,
        D2L = 143,
        D2F = 144,
        I2B = 145,
        I2C = 146,
        I2S = 147,
        LCMP = 148,
        FCMPL = 149,
        FCMPG = 150,
        DCMPL = 151,
        DCMPG = 152,
        IFEQ = 153,
        IFNE = 154,
        IFLT = 155,
        IFGE = 156,
        IFGT = 157,
        IFLE = 158,
        IF_ICMPEQ = 159,
        IF_ICMPNE = 160,
        IF_ICMPLT = 161,
        IF_ICMPGE = 162,
        IF_ICMPGT = 163,
        IF_ICMPLE = 164,
        IF_ACMPEQ = 165,
        IF_ACMPNE = 166,
        GOTO = 167,
        JSR = 168,
        RET = 169,
        TABLESWITCH = 170,
        LOOKUPSWITCH = 171,
        IRETURN = 172,
        LRETURN = 173,
        FRETURN = 174,
        DRETURN = 175,
        ARETURN = 176,
        RETURN = 177,
        GETSTATIC = 178,
        PUTSTATIC = 179,
        GETFIELD = 180,
        PUTFIELD = 181,
        FIRST_INVOKE = 182,
        LAST_INVOKE = 185,
        INVOKEVIRTUAL = 182,
        INVOKESPECIAL = 183,
        INVOKESTATIC = 184,
        INVOKEINTERFACE = 185,
        XXXUNUSEDXXX = 186,
        NEW = 187,
        NEWARRAY = 188,
        ANEWARRAY = 189,
        ARRAYLENGTH = 190,
        ATHROW = 191,
        CHECKCAST = 192,
        INSTANCEOF = 193,
        MONITORENTER = 194,
        MONITOREXIT = 195,
        WIDE = 196,
        MULTIANEWARRAY = 197,
        IFNULL = 198,
        IFNONNULL = 199,
        GOTO_W = 200,
        JSR_W = 201,
        BREAKPOINT = 202,
        ALOAD_ILOAD = 210,
        IINC_GOTO = 211,
        ARRAYLENGTH_IF_ICMPGE = 212,
        RESOLVED_GETFIELD = 213,
        RESOLVED_PUTFIELD = 214,
        RESOLVED_INVOKEVIRTUAL = 215,
        ILLEGAL = 255,
        END = 256,
        /**
         * The last opcode defined by the JVM specification. To iterate over all JVM bytecodes:
         */
        LAST_JVM_OPCODE = 201,
    }
    function getBytecodesName(bytecode: Bytecodes): string;
    /**
     * A array that maps from a bytecode value to the set of {@link Flags} for the corresponding instruction.
     */
    var flags: Uint32Array;
    /**
     * A array that maps from a bytecode value to the length in bytes for the corresponding instruction.
     */
    var length: Uint32Array;
    /**
     * Gets the length of an instruction denoted by a given opcode.
     */
    function lengthOf(opcode: Bytecodes): number;
    function lengthAt(code: Uint8Array, bci: number): number;
    /**
     * Determines if a given opcode denotes an instruction that can cause an implicit exception.
     */
    function canTrap(opcode: Bytecodes): boolean;
    /**
     * Determines if a given opcode denotes an instruction that ends a basic block and does not let control flow fall
     * through to its lexical successor.
     */
    function isStop(opcode: Bytecodes): boolean;
    /**
     * Determines if a given opcode denotes an instruction that stores a value to a local variable
     * after popping it from the operand stack.
     */
    function isInvoke(opcode: Bytecodes): boolean;
    /**
     * Determines if a given opcode denotes an instruction that stores a value to a local variable
     * after popping it from the operand stack.
     */
    function isStore(opcode: Bytecodes): boolean;
    /**
     * Determines if a given opcode is an instruction that delimits a basic block.
     */
    function isBlockEnd(opcode: Bytecodes): boolean;
    /**
     * Determines if a given opcode is a return bytecode.
     */
    function isReturn(opcode: Bytecodes): boolean;
    class BytecodeSwitch {
        /**
         * The bytecode array or {@code null} if {@link #stream} is not {@code null}.
         */
        private code;
        /**
         * Index of start of switch instruction.
         */
        protected bci: number;
        /**
         * Index of the start of the additional data for the switch instruction, aligned to a multiple of four from the method start.
         */
        protected alignedBci: number;
        /**
         * Constructor for a bytecode array.
         * @param code the bytecode array containing the switch instruction.
         * @param bci the index in the array of the switch instruction
         */
        constructor(code: Uint8Array, bci: number);
        /**
         * Gets the index of the instruction denoted by the {@code i}'th switch target.
         * @param i index of the switch target
         * @return the index of the instruction denoted by the {@code i}'th switch target
         */
        targetAt(i: number): number;
        /**
         * Gets the index of the instruction for the default switch target.
         * @return the index of the instruction for the default switch target
         */
        defaultTarget(): number;
        /**
         * Gets the offset from the start of the switch instruction to the default switch target.
         * @return the offset to the default switch target
         */
        defaultOffset(): number;
        /**
         * Gets the key at {@code i}'th switch target index.
         * @param i the switch target index
         * @return the key at {@code i}'th switch target index
         */
        keyAt(i: number): number;
        /**
         * Gets the offset from the start of the switch instruction for the {@code i}'th switch target.
         * @param i the switch target index
         * @return the offset to the {@code i}'th switch target
         */
        offsetAt(i: number): number;
        /**
         * Gets the number of switch targets.
         * @return the number of switch targets
         */
        numberOfCases(): number;
        /**
         * Gets the total size in bytes of the switch instruction.
         * @return the total size in bytes of the switch instruction
         */
        size(): number;
        /**
         * Reads the signed value at given bytecode index.
         * @param bci the start index of the value to retrieve
         * @return the signed, 4-byte value in the bytecode array starting at {@code bci}
         */
        protected readWord(bci: number): number;
    }
    class BytecodeTableSwitch extends BytecodeSwitch {
        private static OFFSET_TO_LOW_KEY;
        private static OFFSET_TO_HIGH_KEY;
        private static OFFSET_TO_FIRST_JUMP_OFFSET;
        private static JUMP_OFFSET_SIZE;
        /**
         * Constructor for a bytecode array.
         * @param code the bytecode array containing the switch instruction.
         * @param bci the index in the array of the switch instruction
         */
        constructor(code: Uint8Array, bci: number);
        /**
         * Gets the low key of the table switch.
         */
        lowKey(): number;
        /**
         * Gets the high key of the table switch.
         */
        highKey(): number;
        keyAt(i: number): number;
        defaultOffset(): number;
        offsetAt(i: number): number;
        numberOfCases(): number;
        size(): number;
    }
    class BytecodeLookupSwitch extends BytecodeSwitch {
        private static OFFSET_TO_NUMBER_PAIRS;
        private static OFFSET_TO_FIRST_PAIR_MATCH;
        private static OFFSET_TO_FIRST_PAIR_OFFSET;
        private static PAIR_SIZE;
        constructor(code: Uint8Array, bci: number);
        defaultOffset(): number;
        offsetAt(i: number): number;
        keyAt(i: any): number;
        numberOfCases(): number;
        size(): number;
    }
    /**
     * A utility class that makes iterating over bytecodes and reading operands
     * simpler and less error prone. For example, it handles the {@link Bytecodes#WIDE} instruction
     * and wide variants of instructions internally.
     */
    class BytecodeStream {
        private _code;
        private _opcode;
        private _currentBCI;
        private _nextBCI;
        constructor(code: Uint8Array);
        /**
         * Advances to the next bytecode.
         */
        next(): void;
        /**
         * Gets the bytecode index of the end of the code.
         */
        endBCI(): number;
        /**
         * Gets the next bytecode index (no side-effects).
         */
        nextBCI: number;
        /**
         * Gets the current bytecode index.
         */
        currentBCI: number;
        /**
         * Gets the current opcode. This method will never return the
         * {@link Bytecodes#WIDE WIDE} opcode, but will instead
         * return the opcode that is modified by the {@code WIDE} opcode.
         * @return the current opcode; {@link Bytecodes#END} if at or beyond the end of the code
         */
        currentBC(): Bytecodes;
        rawCurrentBC(): Bytecodes;
        /**
         * Sets the current opcode.
         */
        writeCurrentBC(bc: Bytecodes): void;
        /**
         * Gets the next opcode.
         * @return the next opcode; {@link Bytecodes#END} if at or beyond the end of the code
         */
        nextBC(): Bytecodes;
        /**
         * Reads the index of a local variable for one of the load or store instructions.
         * The WIDE modifier is handled internally.
         */
        readLocalIndex(): number;
        /**
         * Read the delta for an {@link Bytecodes#IINC} bytecode.
         */
        readIncrement(): number;
        /**
         * Read the destination of a {@link Bytecodes#GOTO} or {@code IF} instructions.
         * @return the destination bytecode index
         */
        readBranchDest(): number;
        /**
         * Read the destination of a {@link Bytecodes#GOTO_W} or {@link Bytecodes#JSR_W} instructions.
         * @return the destination bytecode index
         */
        readFarBranchDest(): number;
        /**
         * Read a signed 4-byte integer from the bytecode stream at the specified bytecode index.
         * @param bci the bytecode index
         * @return the integer value
         */
        readInt(bci: number): number;
        /**
         * Reads an unsigned, 1-byte value from the bytecode stream at the specified bytecode index.
         * @param bci the bytecode index
         * @return the byte
         */
        readUByte(bci: number): number;
        /**
         * Reads a constant pool index for the current instruction.
         * @return the constant pool index
         */
        readCPI(): number;
        /**
         * Reads a signed, 1-byte value for the current instruction (e.g. BIPUSH).
         */
        readByte(): number;
        /**
         * Reads a signed, 2-byte short for the current instruction (e.g. SIPUSH).
         */
        readShort(): number;
        /**
         * Sets the bytecode index to the specified value.
         * If {@code bci} is beyond the end of the array, {@link #currentBC} will return
         * {@link Bytecodes#END} and other methods may throw {@link ArrayIndexOutOfBoundsException}.
         * @param bci the new bytecode index
         */
        setBCI(bci: number): void;
        readTableSwitch(): BytecodeTableSwitch;
        readLookupSwitch(): BytecodeLookupSwitch;
    }
}
declare module J2ME.Bytecode {
    class Block {
        startBci: number;
        endBci: number;
        isExceptionEntry: boolean;
        isLoopHeader: boolean;
        isLoopEnd: boolean;
        hasHandlers: boolean;
        blockID: number;
        relooperBlockID: number;
        region: any;
        successors: Block[];
        predecessors: Block[];
        normalSuccessors: number;
        visited: boolean;
        active: boolean;
        loops: number;
        exits: number;
        loopID: number;
        isInnerLoopHeader(): boolean;
        constructor();
        clone(): Block;
    }
    class ExceptionBlock extends Block {
        handler: ExceptionEntryView;
        deoptBci: number;
    }
    class BlockMap {
        method: MethodInfo;
        blocks: Block[];
        hasBackwardBranches: boolean;
        invokeCount: number;
        private blockMap;
        private startBlock;
        private canTrap;
        constructor(method: MethodInfo);
        build(): void;
        private makeExceptionEntries();
        private computeLoopStores();
        private initializeBlockIDs();
        getBlock(bci: number): Block;
        getOSREntryPoints(): any[];
        private makeBlock(startBci);
        private makeSwitchSuccessors(tswitch);
        private setSuccessors(predBci, successors);
        canTrapAt(opcode: Bytecodes, bci: number): boolean;
        private iterateOverBytecodes();
        /**
         * The next available loop number.
         */
        private _nextLoop;
        /**
         * Mark the block as a loop header, using the next available loop number.
         * Also checks for corner cases that we don't want to compile.
         */
        private makeLoopHeader(block);
        private handlerIsCatchAll(handler);
        private exceptionDispatch;
        private makeExceptionDispatch(handlers, index, bci);
        private addExceptionEdges();
        private fixLoopBits();
        private computeBlockOrder();
        /**
         * Depth-first traversal of the control flow graph. The flag {@linkplain Block#visited} is used to
         * visit every block only once. The flag {@linkplain Block#active} is used to detect cycles (backward
         * edges).
         */
        private computeBlockOrderFrom(block);
        blockToString(block: Block): string;
        trace(writer: IndentingWriter, traceBytecode?: boolean): void;
        traceDOTFile(writer: IndentingWriter): void;
    }
}
declare module J2ME {
    /**
     * The number of opcodes executed thus far.
     */
    var bytecodeCount: number;
    /**
     * The number of times the interpreter method was called thus far.
     */
    var interpreterCount: number;
    var onStackReplacementCount: number;
    /**
     * Calling Convention:
     *
     * Interpreter -> Interpreter:
     *   This follows the JVM bytecode calling convention. This interpreter is highly
     *   optimized for this calling convention.
     *
     * Compiled / Native -> Compiled / Native:
     *   64-bit floats and single word values can be encoded using only one JS value. However, 64-bit longs cannot and
     *   require a (low, high) JS value pair. For example, the signature: "foo.(IDJi)J" is expressed as:
     *
     *   function foo(i, d, lowBits, highBits, i) {
     *     return tempReturn0 = highBits, lowBits;
     *   }
     *
     *   Returning longs is equally problamatic, the convention is to return the lowBits, and save the highBits in a
     *   global |tempReturn0| variable.
     */
    enum FrameType {
        /**
         * Normal interpreter frame.
         */
        Interpreter = 0,
        /**
         * Marks the beginning of a sequence of interpreter frames. If we see this
         * frame when returning we need to exit the interpreter loop.
         */
        ExitInterpreter = 268435456,
        /**
         * Native frames are pending and need to be pushed on the stack.
         */
        PushPendingFrames = 536870912,
        /**
         * Marks the beginning of frames that were not invoked by the previous frame.
         */
        Interrupt = 805306368,
        /**
         * Marks the beginning of native/compiled code called from the interpreter.
         */
        Native = 1073741824,
    }
    const enum FrameLayout {
        /**
         * Stored in the lower 28 bits.
         */
        CalleeMethodInfoOffset = 2,
        CalleeMethodInfoMask = 268435455,
        /**
         * Stored in the upper 4 bits.
         */
        FrameTypeOffset = 2,
        FrameTypeMask = 4026531840,
        CallerFPOffset = 1,
        CallerRAOffset = 0,
        MonitorOffset = 3,
        CallerSaveSize = 4,
    }
    class FrameView {
        fp: number;
        sp: number;
        pc: number;
        thread: Thread;
        constructor();
        set(thread: Thread, fp: number, sp: number, pc: number): void;
        setParameter(kind: Kind, i: number, v: any): void;
        setStackSlot(kind: Kind, i: number, v: any): void;
        methodInfo: MethodInfo;
        type: FrameType;
        parameterOffset: number;
        stackOffset: number;
        traceStack(writer: IndentingWriter, details?: boolean): void;
        trace(writer: IndentingWriter, details?: boolean): void;
    }
    var interpreterCounter: Metrics.Counter;
    class Thread {
        /**
         * Thread base pointer.
         */
        tp: number;
        /**
         * Stack base pointer.
         */
        bp: number;
        /**
         * Current frame pointer.
         */
        fp: number;
        /**
         * Current stack pointer.
         */
        sp: number;
        /**
         * Current program counter.
         */
        pc: number;
        nativeFrameCount: number;
        /**
         * Context associated with this thread.
         */
        ctx: Context;
        view: FrameView;
        /**
         * Stack of native frames seen during unwinding. These appear in reverse order. If a marker frame
         * is seen during unwinding, a null value is also pushed on this stack to mark native frame ranges.
         */
        unwoundNativeFrames: any[];
        /**
         * Stack of native frames to push on the stack.
         */
        pendingNativeFrames: any[];
        constructor(ctx: Context);
        set(fp: number, sp: number, pc: number): void;
        hashFrame(): number;
        frame: FrameView;
        pushMarkerFrame(frameType: FrameType): void;
        pushFrame(methodInfo: MethodInfo, sp?: number, pc?: number, monitorAddr?: number, frameType?: FrameType): void;
        popMarkerFrame(frameType: FrameType): MethodInfo;
        popFrame(methodInfo: MethodInfo, frameType?: FrameType): MethodInfo;
        run(): any;
        exceptionUnwind(e: java.lang.Exception): void;
        classInitAndUnwindCheck(fp: number, sp: number, pc: number, classInfo: ClassInfo): void;
        throwException(fp: number, sp: number, pc: number, type: ExceptionType, a?: any): void;
        tracePendingFrames(writer: IndentingWriter): void;
        pushPendingNativeFrames(): void;
        /**
         * Called when unwinding begins.
         */
        beginUnwind(): void;
        endUnwind(): void;
        /**
         * Walks the stack from the current fp to find the frame that will return
         * to the removeFP and make it instead return to the newCallerFP.
         */
        removeFrame(removeFP: number, newCallerFP: number, newCallerPC: number): void;
    }
    function prepareInterpretedMethod(methodInfo: MethodInfo): Function;
    const enum ExceptionType {
        ArithmeticException = 0,
        ArrayIndexOutOfBoundsException = 1,
        NegativeArraySizeException = 2,
        NullPointerException = 3,
    }
    /**
     * Main interpreter loop. This method is carefully written to avoid memory allocation and
     * function calls on fast paths. Therefore, everything is inlined, even if it makes the code
     * look ugly.
     *
     * The interpreter loop caches the thread state in local variables. Doing so avoids a lot of
     * property accesses but also makes the code brittle since you need to manually sync up the
     * thread state with the local thead state at precise points.
     *
     * At call sites, caller frame |pc|s are always at the beggining of invoke bytecodes. In the
     * interpreter return bytecodes advance the pc past the invoke bytecode. Native code that
     * unwinds and resumes execution at a later point needs to adjust the pc accordingly.
     *
     * Bytecodes that construct exception objects must save the tread state before executing any
     * code that may overwrite the frame. Use the |throwException| helper method to ensure that
     * the thread state is property saved.
     */
    function interpret(thread: Thread): any;
}
declare var $: J2ME.Runtime;
declare var tempReturn0: number;
interface Math {
    fround(value: number): number;
}
interface CompiledMethodCache {
    get(key: string): {
        key: string;
        args: string[];
        body: string;
        referencedClasses: string[];
        onStackReplacementEntryPoints: any;
    };
    put(obj: {
        key: string;
        args: string[];
        body: string;
        referencedClasses: string[];
        onStackReplacementEntryPoints: any;
    }): Promise<any>;
}
interface AOTMetaData {
    /**
     * On stack replacement pc entry points.
     */
    osr: number[];
}
declare var throwHelper: any;
declare var throwPause: any;
declare var throwYield: any;
declare module J2ME {
    function returnLong(l: number, h: number): number;
    function returnDouble(l: number, h: number): number;
    function returnDoubleValue(v: number): number;
    var aotMetaData: {
        string: AOTMetaData;
    };
    /**
     * Turns on just-in-time compilation of methods.
     */
    var enableRuntimeCompilation: boolean;
    /**
     * Turns on onStackReplacement
     */
    var enableOnStackReplacement: boolean;
    /**
     * Turns on caching of JIT-compiled methods.
     */
    var enableCompiledMethodCache: boolean;
    /**
     * Traces method execution.
     */
    var traceWriter: any;
    /**
     * Traces bytecode execution.
     */
    var traceStackWriter: any;
    /**
     * Traces performance problems.
     */
    var perfWriter: any;
    /**
     * Traces linking and class loading.
     */
    var linkWriter: any;
    /**
     * Traces JIT compilation.
     */
    var jitWriter: any;
    /**
     * Traces class loading.
     */
    var loadWriter: any;
    /**
     * Traces winding and unwinding.
     */
    var windingWriter: any;
    /**
     * Traces class initialization.
     */
    var initWriter: any;
    /**
     * Traces thread execution.
     */
    var threadWriter: any;
    /**
     * Traces generated code.
     */
    var codeWriter: any;
    const enum MethodState {
        /**
         * All methods start in this state.
         */
        Cold = 0,
        /**
         * Methods have this state if code has been compiled for them or
         * there is a native implementation that needs to be used.
         */
        Compiled = 1,
        /**
         * We don't want to compiled these methods, they may be too large
         * to benefit from JIT compilation.
         */
        NotCompiled = 2,
        /**
         * Methods are not compiled because of some exception.
         */
        CannotCompile = 3,
    }
    var timeline: any;
    var threadTimeline: any;
    var methodTimelines: any[];
    var gcCounter: Metrics.Counter;
    var nativeCounter: Metrics.Counter;
    var runtimeCounter: Metrics.Counter;
    var baselineMethodCounter: Metrics.Counter;
    var asyncCounter: Metrics.Counter;
    var unwindCount: number;
    function enterTimeline(name: string, data?: any): void;
    function leaveTimeline(name?: string, data?: any): void;
    var stdoutWriter: IndentingWriter;
    var stderrWriter: IndentingWriter;
    const enum ExecutionPhase {
        /**
         * Default runtime behaviour.
         */
        Runtime = 0,
        /**
         * When compiling code statically.
         */
        Compiler = 1,
    }
    var phase: ExecutionPhase;
    var internedStrings: TypedArrayHashtable;
    const enum RuntimeStatus {
        New = 1,
        Started = 2,
        Stopping = 3,
        Stopped = 4,
    }
    const enum MethodType {
        Interpreted = 0,
        Native = 1,
        Compiled = 2,
    }
    function getMethodTypeName(methodType: MethodType): any;
    function hashUTF8String(s: Uint8Array): number;
    function escapeString(s: string): string;
    function hashStringToString(s: string): any;
    /**
     * This class is abstract and should never be initialized. It only acts as a template for
     * actual runtime objects.
     */
    class RuntimeTemplate {
        static all: Set<{}>;
        jvm: JVM;
        status: RuntimeStatus;
        waiting: any[];
        threadCount: number;
        initialized: Int8Array;
        staticObjectAddresses: Int32Array;
        classObjectAddresses: Int32Array;
        I: Int8Array;
        SA: Int32Array;
        CO: Int32Array;
        ctx: Context;
        allCtxs: Set<Context>;
        isolateId: number;
        isolateAddress: number;
        priority: number;
        mainThread: number;
        private static _nextRuntimeId;
        private _runtimeId;
        private _nextHashCode;
        constructor(jvm: JVM);
        preInitializeClasses(ctx: Context): void;
        /**
         * After class initialization is finished the init9 method will invoke this so
         * any further initialize calls can be avoided. This isn't set on the first call
         * to a class initializer because there can be multiple calls into initialize from
         * different threads that need trigger the Class.initialize() code so they block.
         */
        setClassInitialized(classId: number): void;
        getClassObjectAddress(classInfo: ClassInfo): number;
        /**
         * Generates a new hash code for the specified |object|.
         */
        nextHashCode(): number;
        waitStatus(callback: any): void;
        updateStatus(status: RuntimeStatus): void;
        addContext(ctx: any): void;
        removeContext(ctx: any): void;
        newStringConstant(utf16ArrayAddr: number): number;
        newIOException(str?: string): java.io.IOException;
        newUnsupportedEncodingException(str?: string): java.io.UnsupportedEncodingException;
        newUTFDataFormatException(str?: string): java.io.UTFDataFormatException;
        newSecurityException(str?: string): java.lang.SecurityException;
        newIllegalThreadStateException(str?: string): java.lang.IllegalThreadStateException;
        newRuntimeException(str?: string): java.lang.RuntimeException;
        newIndexOutOfBoundsException(str?: string): java.lang.IndexOutOfBoundsException;
        newArrayIndexOutOfBoundsException(str?: string): java.lang.ArrayIndexOutOfBoundsException;
        newStringIndexOutOfBoundsException(str?: string): java.lang.StringIndexOutOfBoundsException;
        newArrayStoreException(str?: string): java.lang.ArrayStoreException;
        newIllegalMonitorStateException(str?: string): java.lang.IllegalMonitorStateException;
        newClassCastException(str?: string): java.lang.ClassCastException;
        newArithmeticException(str?: string): java.lang.ArithmeticException;
        newClassNotFoundException(str?: string): java.lang.ClassNotFoundException;
        newIllegalArgumentException(str?: string): java.lang.IllegalArgumentException;
        newIllegalStateException(str?: string): java.lang.IllegalStateException;
        newNegativeArraySizeException(str?: string): java.lang.NegativeArraySizeException;
        newNullPointerException(str?: string): java.lang.NullPointerException;
        newMediaException(str?: string): javax.microedition.media.MediaException;
        newInstantiationException(str?: string): java.lang.InstantiationException;
        newException(str?: string): java.lang.Exception;
        static classInfoComplete(classInfo: ClassInfo): void;
    }
    const enum VMState {
        Running = 0,
        Yielding = 1,
        Pausing = 2,
        Stopping = 3,
    }
    function getVMStateName(vmState: VMState): string;
    const enum Constants {
        BYTE_MIN = -128,
        BYTE_MAX = 127,
        SHORT_MIN = -32768,
        SHORT_MAX = 32767,
        CHAR_MIN = 0,
        CHAR_MAX = 65535,
        INT_MIN = -2147483648,
        INT_MAX = 2147483647,
        LONG_MAX_LOW = 4294967295,
        LONG_MAX_HIGH = 2147483647,
        LONG_MIN_LOW = 0,
        LONG_MIN_HIGH = 2147483648,
        MAX_STACK_SIZE = 4096,
        TWO_PWR_32_DBL = 4294967296,
        TWO_PWR_63_DBL = 9223372036854776000,
        OBJ_HDR_SIZE = 8,
        OBJ_CLASS_ID_OFFSET = 0,
        HASH_CODE_OFFSET = 4,
        ARRAY_HDR_SIZE = 8,
        ARRAY_LENGTH_OFFSET = 4,
        NULL = 0,
        MAX_METHOD_ID = 16383,
        INITIAL_MAX_METHOD_ID = 511,
        MAX_CLASS_ID = 4095,
        INITIAL_MAX_CLASS_ID = 511,
        LOG_MAX_FLAT_VTABLE_SIZE = 6,
    }
    class Runtime extends RuntimeTemplate {
        private static _nextId;
        id: number;
        /**
         * Bailout callback whenever a JIT frame is unwound.
         */
        B(methodId: number, pc: number, lockObjectAddress: number): void;
        yield(reason: string): void;
        nativeBailout(returnKind: Kind, opCode?: Bytecode.Bytecodes): void;
        pause(reason: string): void;
        stop(): void;
        constructor(jvm: JVM);
    }
    var classIdToClassInfoMap: any[];
    var methodIdToMethodInfoMap: any[];
    var linkedMethods: any[];
    function registerClassId(classId: number, classInfo: ClassInfo): void;
    function registerMethodId(methodId: number, methodInfo: MethodInfo): void;
    /**
     * Maps classIds to vTables containing JS functions.
     */
    var linkedVTableMap: any[];
    /**
     * Flat map of classId and vTableIndex to JS functions. This allows the compiler to
     * emit a single memory load to lookup a vTable entry
     *  flatLinkedVTableMap[classId << LOG_MAX_FLAT_VTABLE_SIZE + vTableIndex]
     * instead of the slower more general
     *  linkedVTableMap[classId][vTableIndex]
     */
    var flatLinkedVTableMap: any[];
    function getClassInfo(addr: number): any;
    /**
     * A map from addresses to monitors, which are JS objects that we use to track
     * the lock state of Java objects.
     *
     * In most cases, we create the JS objects via Object.create(null), but we use
     * java.lang.Class objects for classes, since those continue to be represented
     * by JS objects in the runtime.  We also overload this map to retrieve those
     * class objects for other purposes.
     *
     * XXX Consider storing lock state in the ASM heap.
     */
    var monitorMap: any;
    function getMonitor(ref: number): Lock;
    /**
     * Representation of a Java class with JS object.
     */
    interface Handle extends Function {
        new (address?: number): java.lang.Object;
        _address: number;
        classInfo: ClassInfo;
    }
    class Lock {
        threadAddress: number;
        level: number;
        ready: Context[];
        waiting: Context[];
        constructor(threadAddress: number, level: number);
    }
    function getLinkedMethod(methodInfo: MethodInfo): any;
    function getLinkedMethodById(methodId: number): any;
    function getLinkedVirtualMethodById(classId: number, vTableIndex: number): any;
    /**
     * Number of methods that have been compiled thus far.
     */
    var compiledMethodCount: number;
    /**
     * Maximum number of methods to compile.
     */
    var maxCompiledMethodCount: number;
    /**
     * Number of methods that have not been compiled thus far.
     */
    var notCompiledMethodCount: number;
    /**
     * Number of methods that have been loaded from the code cache thus far.
     */
    var cachedMethodCount: number;
    /**
     * Number of methods that have been loaded from ahead of time compiled code thus far.
     */
    var aotMethodCount: number;
    /**
     * Compiles method and links it up at runtime.
     */
    function compileAndLinkMethod(methodInfo: MethodInfo): void;
    var classInfoSymbolPrefix: string;
    var methodInfoSymbolPrefix: string;
    /**
     * Links up compiled method at runtime.
     */
    function linkMethodSource(methodInfo: MethodInfo, args: string[], body: string, referencedClasses: ClassInfo[], onStackReplacementEntryPoints: any): void;
    function isAssignableTo(from: ClassInfo, to: ClassInfo): boolean;
    function instanceOfKlass(objectAddr: number, classId: number): boolean;
    function instanceOfInterface(objectAddr: number, classId: number): boolean;
    function checkCastKlass(objectAddr: number, classId: number): void;
    function checkCastInterface(objectAddr: number, classId: number): void;
    function allocUncollectableObject(classInfo: ClassInfo): number;
    function allocObject(classInfo: ClassInfo): number;
    function getFreeMemory(): number;
    function onFinalize(addr: number): void;
    const enum BailoutFrameLayout {
        MethodIdOffset = 0,
        PCOffset = 4,
        LocalCountOffset = 8,
        StackCountOffset = 12,
        LockOffset = 16,
        HeaderSize = 20,
    }
    function createBailoutFrame(methodId: number, pc: number, localCount: number, stackCount: number, lockObjectAddress: number): number;
    /**
     * A map from Java object addresses to native objects.
     *
     * Currently this only supports mapping an address to a single native.
     * Will we ever want to map multiple natives to an address?  If so, we'll need
     * to do something more sophisticated here.
     */
    var NativeMap: Map<number, Object>;
    function setNative(addr: number, obj: Object): void;
    /**
     * Get a handle for an object in the ASM heap.
     *
     * Currently, we implement this using JS constructors (i.e. Klass instances)
     * with a prototype chain that reflects the Java class hierarchy and getters/
     * setters for fields.
     */
    function getHandle(address: number): java.lang.Object;
    function newString(jsString: string): number;
    function getArrayFromAddr(addr: number): any;
    function setUncollectable(addr: number): void;
    function unsetUncollectable(addr: number): void;
    function newArray(elementClassInfo: ClassInfo, size: number): number;
    function newMultiArray(classInfo: ClassInfo, lengths: number[]): number;
    var JavaRuntimeException: (message: any) => void;
    function throwNegativeArraySizeException(): void;
    function throwNullPointerException(): void;
    function newObjectArray(size: number): number;
    function newStringArray(size: number): number;
    function newByteArray(size: number): number;
    function newCharArray(size: number): number;
    function newIntArray(size: number): number;
    function fromJavaChars(charsAddr: any, offset: any, count: any): string;
    function fromStringAddr(stringAddr: number): string;
    function checkDivideByZero(value: number): void;
    /**
     * Do bounds check using only one branch. The math works out because array.length
     * can't be larger than 2^31 - 1. So |index| >>> 0 will be larger than
     * array.length if it is less than zero. We need to make the right side unsigned
     * as well because otherwise the SM optimization that converts this to an
     * unsinged branch doesn't kick in.
     */
    function checkArrayBounds(array: any[], index: number): void;
    function throwArrayIndexOutOfBoundsException(index: number): void;
    function throwArithmeticException(): void;
    function checkArrayStore(arrayAddr: number, valueAddr: number): void;
    function checkNull(object: java.lang.Object): void;
    class ConfigThresholds {
        static InvokeThreshold: any;
        static BackwardBranchThreshold: any;
    }
    function monitorEnter(lock: Lock): void;
    function monitorExit(lock: Lock): void;
    function translateException(e: any): any;
    function classInitCheck(classInfo: ClassInfo): void;
    function preempt(): void;
    class UnwindThrowLocation {
        static instance: UnwindThrowLocation;
        pc: number;
        sp: number;
        nextPC: number;
        constructor();
        setLocation(pc: number, nextPC: number, sp: number): UnwindThrowLocation;
        getPC(): number;
        getSP(): number;
    }
    /**
     * Helper methods used by the compiler.
     */
    /**
     * Generic unwind throw.
     */
    function throwUnwind(pc: number, nextPC?: number, sp?: number): void;
    /**
     * Unwind throws with different stack heights. This is useful so we can
     * save a few bytes encoding the stack height in the function name.
     */
    function throwUnwind0(pc: number, nextPC?: number): void;
    function throwUnwind1(pc: number, nextPC?: number): void;
    function throwUnwind2(pc: number, nextPC?: number): void;
    function throwUnwind3(pc: number, nextPC?: number): void;
    function throwUnwind4(pc: number, nextPC?: number): void;
    function throwUnwind5(pc: number, nextPC?: number): void;
    function throwUnwind6(pc: number, nextPC?: number): void;
    function throwUnwind7(pc: number, nextPC?: number): void;
    function fadd(a: number, b: number): number;
    function fsub(a: number, b: number): number;
    function fmul(a: number, b: number): number;
    function fdiv(a: number, b: number): number;
    function frem(a: number, b: number): number;
    function fcmp(a: number, b: number, isLessThan: boolean): number;
    function fneg(a: number): number;
    function dcmp(al: number, ah: number, bl: number, bh: number, isLessThan: boolean): number;
    function dadd(al: number, ah: number, bl: number, bh: number): number;
    function dsub(al: number, ah: number, bl: number, bh: number): number;
    function dmul(al: number, ah: number, bl: number, bh: number): number;
    function ddiv(al: number, ah: number, bl: number, bh: number): number;
    function drem(al: number, ah: number, bl: number, bh: number): number;
    function dneg(al: number, ah: number): number;
    function f2i(a: number): number;
    function d2i(al: number, ah: number): number;
    function i2f(a: number): number;
    function i2d(a: number): number;
    function l2d(al: number, ah: number): number;
    function l2f(al: number, ah: number): number;
    function f2d(l: number): number;
    function f2l(l: number): number;
    function d2l(al: number, ah: number): number;
    function d2f(al: number, ah: number): number;
    function gcMalloc(size: number): number;
    function gcMallocAtomic(size: number): number;
    function gcMallocUncollectable(size: number): number;
    function lcmp(al: number, ah: number, bl: number, bh: number): number;
    function ladd(al: number, ah: number, bl: number, bh: number): number;
    function lsub(al: number, ah: number, bl: number, bh: number): number;
    function lmul(al: number, ah: number, bl: number, bh: number): number;
    function ldiv(al: number, ah: number, bl: number, bh: number): number;
    function lrem(al: number, ah: number, bl: number, bh: number): number;
    function lneg(al: number, ah: number): number;
    function lshl(al: number, ah: number, shift: number): number;
    function lshr(al: number, ah: number, shift: number): number;
    function lushr(al: number, ah: number, shift: number): number;
}
declare var Runtime: typeof J2ME.Runtime;
declare var AOTMD: {
    string: AOTMetaData;
};
/**
 * Are we currently unwinding the stack because of a Yield? This technically
 * belonges to a context but we store it in the global object because it is
 * read very often.
 */
declare var U: J2ME.VMState;
declare var B0: typeof J2ME.throwUnwind0;
declare var B1: typeof J2ME.throwUnwind1;
declare var B2: typeof J2ME.throwUnwind2;
declare var B3: typeof J2ME.throwUnwind3;
declare var B4: typeof J2ME.throwUnwind4;
declare var B5: typeof J2ME.throwUnwind5;
declare var B6: typeof J2ME.throwUnwind6;
declare var B7: typeof J2ME.throwUnwind7;
/**
 * OSR Frame.
 */
declare var O: J2ME.MethodInfo;
/**
 * Runtime exports for compiled code.
 * DO NOT use these short names outside of compiled code.
 */
declare var CI: any[];
declare var MI: any[];
declare var LM: any[];
declare var GLM: typeof J2ME.getLinkedMethodById;
declare var GLVM: typeof J2ME.getLinkedVirtualMethodById;
declare var VT: any[];
declare var FT: any[];
declare var CIC: typeof J2ME.classInitCheck;
declare var GH: typeof J2ME.getHandle;
declare var AO: typeof J2ME.allocObject;
declare var IOK: typeof J2ME.instanceOfKlass;
declare var IOI: typeof J2ME.instanceOfInterface;
declare var CCK: typeof J2ME.checkCastKlass;
declare var CCI: typeof J2ME.checkCastInterface;
declare var NA: typeof J2ME.newArray;
declare var NM: typeof J2ME.newMultiArray;
declare var CAB: typeof J2ME.checkArrayBounds;
declare var CAS: typeof J2ME.checkArrayStore;
declare var GM: typeof J2ME.getMonitor;
declare var ME: typeof J2ME.monitorEnter;
declare var MX: typeof J2ME.monitorExit;
declare var TE: typeof J2ME.translateException;
declare var TI: typeof J2ME.throwArrayIndexOutOfBoundsException;
declare var TA: typeof J2ME.throwArithmeticException;
declare var TS: typeof J2ME.throwNegativeArraySizeException;
declare var TN: typeof J2ME.throwNullPointerException;
declare var PE: typeof J2ME.preempt;
declare var PS: number;
declare var MA: typeof J2ME.gcMallocAtomic;
declare var fadd: typeof J2ME.fadd;
declare var fsub: typeof J2ME.fsub;
declare var fmul: typeof J2ME.fmul;
declare var fdiv: typeof J2ME.fdiv;
declare var frem: typeof J2ME.frem;
declare var fneg: typeof J2ME.fneg;
declare var f2i: typeof J2ME.f2i;
declare var f2l: typeof J2ME.f2l;
declare var f2d: typeof J2ME.f2d;
declare var i2f: typeof J2ME.i2f;
declare var i2d: typeof J2ME.i2d;
declare var d2i: typeof J2ME.d2i;
declare var d2l: typeof J2ME.d2l;
declare var d2f: typeof J2ME.d2f;
declare var l2f: typeof J2ME.l2f;
declare var l2d: typeof J2ME.l2d;
declare var fcmp: typeof J2ME.fcmp;
declare var dneg: typeof J2ME.dneg;
declare var dcmp: typeof J2ME.dcmp;
declare var dadd: typeof J2ME.dadd;
declare var dsub: typeof J2ME.dsub;
declare var dmul: typeof J2ME.dmul;
declare var ddiv: typeof J2ME.ddiv;
declare var drem: typeof J2ME.drem;
declare var lneg: typeof J2ME.lneg;
declare var ladd: typeof J2ME.ladd;
declare var lsub: typeof J2ME.lsub;
declare var lmul: typeof J2ME.lmul;
declare var ldiv: typeof J2ME.ldiv;
declare var lrem: typeof J2ME.lrem;
declare var lcmp: typeof J2ME.lcmp;
declare var lshl: typeof J2ME.lshl;
declare var lshr: typeof J2ME.lshr;
declare var lushr: typeof J2ME.lushr;
declare var getHandle: typeof J2ME.getHandle;
declare var NativeMap: Map<number, Object>;
declare var setNative: typeof J2ME.setNative;
declare module J2ME {
    const enum UTF8Chars {
        a = 97,
        Z = 90,
        C = 67,
        F = 70,
        D = 68,
        B = 66,
        S = 83,
        I = 73,
        J = 74,
        V = 86,
        L = 76,
        OpenBracket = 91,
        Semicolon = 59,
        Dot = 46,
        Slash = 47,
        OpenParenthesis = 40,
        CloseParenthesis = 41,
    }
    function strcmp(a: Uint8Array, b: Uint8Array): boolean;
    /**
     * Caches frequently used UTF8 strings. Only use this for a small set of frequently
     * used JS -> UTF8 conversions.
     */
    function cacheUTF8(s: string): any;
    function toUTF8(s: string): Uint8Array;
    function fromUTF8(s: Uint8Array): string;
    /**
     * Base class of all class file structs.
     */
    class ByteStream {
        buffer: Uint8Array;
        offset: number;
        private static internedOneByteArrays;
        private static internedThreeByteArraySignatures;
        private static internedMap;
        static UTF8toUTF16(utf8: Uint8Array): number;
        constructor(buffer: Uint8Array, offset: number);
        u2(offset: number): number;
        clone(): ByteStream;
        readU1(): number;
        peekU1(): number;
        readU2(): number;
        peekU16(): number;
        readU4(): number;
        skipU4(): void;
        readS4(): number;
        seek(offset: number): ByteStream;
        skip(length: number): ByteStream;
        /**
         * Interns small and frequently used Uint8Array buffers.
         *
         * Relative frequencies of readByte sizes.
         *  2011: readBytes 2
         *  1853: readBytes 1 - Special cased.
         *  1421: readBytes 4
         *  1170: readBytes 5
         *  1042: readBytes 3 - Special cased, most three byte buffers are signatures of the form "()?".
         *  1022: readBytes 6
         *
         * All other sizes are interned using a hashtable.
         */
        internBytes(length: number): Uint8Array;
        readBytes(length: number): Uint8Array;
        readInternedBytes(length: number): Uint8Array;
        static arrays: string[][];
        static getArray(length: number): string[];
        static readStringFast(buffer: Uint8Array): string;
        static readString(buffer: Uint8Array): any;
        static readStringSlow(buffer: Uint8Array): any;
        static readU16(buffer: Uint8Array, o: number): number;
    }
    const enum ACCESS_FLAGS {
        ACC_PUBLIC = 1,
        ACC_PRIVATE = 2,
        ACC_PROTECTED = 4,
        ACC_STATIC = 8,
        ACC_FINAL = 16,
        ACC_SYNCHRONIZED = 32,
        ACC_VOLATILE = 64,
        ACC_TRANSIENT = 128,
        ACC_NATIVE = 256,
        ACC_INTERFACE = 512,
        ACC_ABSTRACT = 1024,
        J2ME_IMPLEMENTS_INTERFACE = 65536,
    }
    const enum TAGS {
        CONSTANT_Class = 7,
        CONSTANT_Fieldref = 9,
        CONSTANT_Methodref = 10,
        CONSTANT_InterfaceMethodref = 11,
        CONSTANT_String = 8,
        CONSTANT_Integer = 3,
        CONSTANT_Float = 4,
        CONSTANT_Long = 5,
        CONSTANT_Double = 6,
        CONSTANT_NameAndType = 12,
        CONSTANT_Utf8 = 1,
        CONSTANT_Unicode = 2,
        CONSTANT_Any = 13,
    }
    function getTAGSName(tag: TAGS): string;
    class ConstantPool extends ByteStream {
        /**
         * Starting positions of each entry in the constant pool.
         */
        entries: Uint32Array;
        /**
         * Resolved constant pool references.
         */
        resolved: any[];
        /**
         * Size of each tag. This is used to jump over constant pool entries quickly.
         */
        private static tagSize;
        constructor(stream: ByteStream);
        /**
         * Quickly scan over the constant pool and record the position of each constant pool entry.
         */
        private scanEntries();
        resolveUtf8(i: number): Uint8Array;
        /**
         * Reads a 16-bit number at an offset from the constant pool entry index.
         */
        readTagU2(i: number, tag: TAGS, offset: number): number;
        /**
         * Seeks the current stream position to a specified constant pool entry and
         * returns the tag value.
         */
        private seekTag(i);
        peekTag(i: number): TAGS;
        /**
         * This causes the Utf8 string to be redecoded each time so don't use it often.
         */
        resolveUtf8String(i: number): string;
        resolveUtf8ClassNameString(i: number): string;
        resolveUtf8ClassName(i: number): Uint8Array;
        getConstantTag(i: number): TAGS;
        resolveString(i: number): string;
        /**
         * Resolves a constant pool reference.
         */
        resolve(i: number, expectedTag: TAGS, isStatic?: boolean): any;
        resolveClass(index: number): ClassInfo;
        resolveMethod(index: number, isStatic: boolean): MethodInfo;
        resolveField(index: number, isStatic: boolean): FieldInfo;
    }
    class FieldInfo extends ByteStream {
        classInfo: ClassInfo;
        kind: Kind;
        byteOffset: number;
        utf8Name: Uint8Array;
        utf8Signature: Uint8Array;
        mangledName: string;
        accessFlags: ACCESS_FLAGS;
        fTableIndex: number;
        constructor(classInfo: ClassInfo, offset: number);
        isStatic: boolean;
        private scanFieldInfoAttributes();
    }
    class SourceLocation {
        className: string;
        sourceFile: string;
        lineNumber: number;
        constructor(className: string, sourceFile: string, lineNumber: number);
        toString(): string;
        equals(other: SourceLocation): boolean;
    }
    class MethodInfoStats {
        callCount: number;
        bytecodeCount: number;
        backwardsBranchCount: number;
        interpreterCallCount: number;
    }
    class ExceptionEntryView extends ByteStream {
        start_pc: number;
        end_pc: number;
        handler_pc: number;
        catch_type: number;
    }
    function mangleClassAndMethod(methodInfo: MethodInfo): string;
    function mangleMethod(methodInfo: MethodInfo): string;
    /**
     * Encodes variable length utf8 alpha strings of the form [a-z]* to
     * 32 bit numbers. Below are some sample encodings:
     *
     *  "" => 0
     *  "a" => 1
     *  "b" => 2 ...
     *  "z" => 26
     *  "aa" => 27
     *  "ab" => 28 ...
     *  "zz" => 703
     *  "aaa" => 704
     *  "azz" => 1378
     *  "zzz" => 18278
     *
     *  The goal of this encoding is to map short strings to low numeric values
     *  that we can then use to index into tables.
     */
    function lowerCaseAlphaToInt32(utf8String: Uint8Array): number;
    function mangleClassName(utf8Name: Uint8Array): string;
    class MethodInfo extends ByteStream {
        private static nextId;
        classInfo: ClassInfo;
        accessFlags: ACCESS_FLAGS;
        fn: any;
        index: number;
        id: number;
        state: MethodState;
        stats: MethodInfoStats;
        codeAttribute: CodeAttribute;
        utf8Name: Uint8Array;
        utf8Signature: Uint8Array;
        returnKind: Kind;
        signatureKinds: Kind[];
        argumentSlots: number;
        signatureSlots: number;
        hasTwoSlotArguments: boolean;
        vTableIndex: number;
        private _virtualName;
        private _mangledName;
        private _mangledClassAndMethodName;
        private _implKey;
        private _name;
        private _signature;
        onStackReplacementEntryPoints: number[];
        exception_table_length: number;
        exception_table_offset: number;
        isOptimized: boolean;
        constructor(classInfo: ClassInfo, offset: number, index: number);
        /**
         * Clones this method info.
         */
        cloneMethodInfo(): MethodInfo;
        virtualName: string;
        mangledName: string;
        mangledClassAndMethodName: string;
        name: string;
        signature: string;
        implementsInterface: boolean;
        implKey: string;
        isNative: boolean;
        isFinal: boolean;
        isPublic: boolean;
        isStatic: boolean;
        isSynchronized: boolean;
        isAbstract: boolean;
        getSourceLocationForPC(pc: number): SourceLocation;
        getExceptionEntryViewByIndex(i: number): ExceptionEntryView;
        scanMethodInfoAttributes(): void;
    }
    class CodeAttribute {
        max_stack: number;
        max_locals: number;
        code: Uint8Array;
        constructor(s: ByteStream);
    }
    class ClassInfo extends ByteStream {
        /**
         * We use this ID to map Java objects to their ClassInfo objects,
         * storing the ID for the Class in the first four bytes
         * of the memory allocated for the Java object in the ASM heap.
         *
         */
        private static nextId;
        constantPool: ConstantPool;
        utf8Name: Uint8Array;
        utf8SuperName: Uint8Array;
        superClass: ClassInfo;
        elementClass: ClassInfo;
        subClasses: ClassInfo[];
        allSubClasses: ClassInfo[];
        depth: number;
        private display;
        accessFlags: number;
        vTable: MethodInfo[];
        iTable: {
            [name: string]: MethodInfo;
        };
        private vTableMap;
        fTable: FieldInfo[];
        sizeOfFields: number;
        sizeOfStaticFields: number;
        private resolvedFlags;
        private fields;
        private methods;
        private interfaces;
        private allInterfaces;
        sourceFile: string;
        mangledName: string;
        id: number;
        private _name;
        private _superName;
        constructor(buffer: Uint8Array);
        /**
         * Creates synthetic methodInfo objects in abstract classes for all unimplemented
         * interface methods. This is needed so that vTable entries are created correctly
         * for abstract classes that don't otherwise define methods for their implemented
         * interface.
         */
        private createAbstractMethods();
        private scanInterfaces();
        private scanFields();
        getClassNameSlow(): string;
        superClassName: string;
        /**
         * Gets the class hierarchy in derived -> base order.
         */
        private getClassHierarchy();
        private trace(writer);
        complete(): void;
        /**
         * Constructs the VTable for this class by appending to or overriding methods
         * in the super class VTable.
         */
        private buildVTable();
        private buildITable();
        private buildFTable();
        private scanMethods();
        private addVTableEntry(accessFlags, name_index, descriptor_index);
        private skipAttributes();
        scanClassInfoAttributes(): void;
        getMethodByIndex(i: number): MethodInfo;
        indexOfMethod(utf8Name: Uint8Array, utf8Signature: Uint8Array): number;
        getMethodByNameString(name: string, signature: string): MethodInfo;
        getLocalMethodByNameString(name: string, signature: string): MethodInfo;
        getLocalMethodByName(utf8Name: Uint8Array, utf8Signature: Uint8Array): MethodInfo;
        getMethodByName(utf8Name: Uint8Array, utf8Signature: Uint8Array): MethodInfo;
        getMethodCount(): number;
        getMethods(): MethodInfo[];
        getFieldByIndex(i: number): FieldInfo;
        indexOfField(utf8Name: Uint8Array, utf8Signature: Uint8Array): number;
        getFieldByName(utf8Name: Uint8Array, utf8Signature: Uint8Array, isStatic: boolean): FieldInfo;
        getFields(): FieldInfo[];
        getInterface(i: number): ClassInfo;
        getInterfaces(): ClassInfo[];
        getAllInterfaces(): ClassInfo[];
        staticInitializer: MethodInfo;
        isInterface: boolean;
        isAbstract: boolean;
        isFinal: boolean;
        implementsInterface(i: ClassInfo): boolean;
        isAssignableTo(toClass: ClassInfo): boolean;
        /**
          * Creates lookup tables used to efficiently implement type checks.
          */
        getDisplay(): ClassInfo[];
    }
    class PrimitiveClassInfo extends ClassInfo {
        constructor(utf8Name: any, mangledName: any);
        static Z: PrimitiveClassInfo;
        static C: PrimitiveClassInfo;
        static F: PrimitiveClassInfo;
        static D: PrimitiveClassInfo;
        static B: PrimitiveClassInfo;
        static S: PrimitiveClassInfo;
        static I: PrimitiveClassInfo;
        static J: PrimitiveClassInfo;
    }
    class ArrayClassInfo extends ClassInfo {
        constructor(elementClass: ClassInfo);
    }
    class ObjectArrayClassInfo extends ArrayClassInfo {
        constructor(elementClass: ClassInfo);
    }
    class PrimitiveArrayClassInfo extends ArrayClassInfo {
        bytesPerElement: number;
        constructor(elementClass: ClassInfo, mangledName: string, bytesPerElement: number);
        static initialize(): void;
        static Z: PrimitiveArrayClassInfo;
        static C: PrimitiveArrayClassInfo;
        static F: PrimitiveArrayClassInfo;
        static D: PrimitiveArrayClassInfo;
        static B: PrimitiveArrayClassInfo;
        static S: PrimitiveArrayClassInfo;
        static I: PrimitiveArrayClassInfo;
        static J: PrimitiveArrayClassInfo;
    }
}
declare module J2ME {
    import Bytecodes = Bytecode.Bytecodes;
    const enum Kind {
        Boolean = 0,
        Byte = 1,
        Short = 2,
        Char = 3,
        Int = 4,
        Float = 5,
        Long = 6,
        Double = 7,
        Reference = 8,
        Void = 9,
        Illegal = 10,
        High = 11,
        Store = 12,
    }
    function getKindName(kind: Kind): string;
    function isTwoSlot(kind: Kind): boolean;
    var valueKinds: Kind[];
    function returnKind(op: Bytecodes): Kind;
    function stackKind(kind: Kind): Kind;
    function kindCharacterToKind(kindCharacter: string): Kind;
    function arrayTypeCodeToKind(typeCode: any): Kind;
    function kindSize(kind: Kind): number;
    function getKindCheck(kind: Kind): (l: any, h: number) => boolean;
    function getSignatureKind(signature: Uint8Array): Kind;
    /**
     * Returns an array of kinds that appear in a method signature. The first element is always the
     * return kind. The returned array is shared, so you if you need a copy of it, you'll need to
     * clone it.
     *
     * The parsing algorithm needs some global state to keep track of the current position in the
     * descriptor, namely |globalNextIndex| which always points to the next index in the descriptor
     * after a token has been consumed.
     */
    function parseMethodDescriptorKinds(value: Uint8Array, startIndex: number): Kind[];
    function signatureHasTwoSlotArguments(signatureKinds: Kind[]): boolean;
    function signatureArgumentSlotCount(signatureKinds: Kind[]): number;
}
declare module J2ME {
    var classCounter: Metrics.Counter;
    class ClassRegistry {
        /**
         * List of directories to look for source files in.
         */
        sourceDirectories: string[];
        /**
         * All source code, only ever used for debugging.
         */
        sourceFiles: Map<string, string[]>;
        unwindMethodInfos: Map<Kind, MethodInfo>;
        /**
         * List of classes whose sources files were not found. We keep track
         * of them so we don't have to search for them over and over.
         */
        missingSourceFiles: Map<string, string[]>;
        classes: Map<string, ClassInfo>;
        preInitializedClasses: ClassInfo[];
        java_lang_Object: ClassInfo;
        java_lang_Class: ClassInfo;
        java_lang_String: ClassInfo;
        java_lang_Thread: ClassInfo;
        constructor();
        initializeBuiltinClasses(): void;
        isPreInitializedClass(classInfo: ClassInfo): boolean;
        addSourceDirectory(name: string): void;
        getSourceLine(sourceLocation: SourceLocation): string;
        loadClassBytes(bytes: Uint8Array): ClassInfo;
        loadClassFile(fileName: string): ClassInfo;
        loadClass(className: string): ClassInfo;
        getEntryPoint(classInfo: ClassInfo): MethodInfo;
        getClass(className: string): ClassInfo;
        createArrayClass(typeName: string): ArrayClassInfo;
        getUnwindMethodInfo(returnKind: Kind, opCode?: Bytecode.Bytecodes): MethodInfo;
    }
    var ClassNotFoundException: (message: any) => void;
}
declare module J2ME {
    var BindingsMap: TypedArrayHashtable;
    module java.lang {
        interface Object {
            /**
             * Reference to the class info.
             */
            classInfo: ClassInfo;
            /**
             * All objects have an address.
             */
            _address: number;
            /**
             * All objects have an internal hash code.
             */
            _hashCode: number;
            /**
             * Some objects may have a lock.
             */
            _lock: Lock;
            clone(): java.lang.Object;
            equals(obj: java.lang.Object): boolean;
            finalize(): void;
            getClass(): java.lang.Class;
            hashCode(): number;
            notify(): void;
            notifyAll(): void;
            toString(): java.lang.String;
            notify(): void;
            notify(timeout: number): void;
            notify(timeout: number, nanos: number): void;
        }
        interface Class extends java.lang.Object {
            status: number;
            initialize(): void;
            vmClass: number;
        }
        interface String extends java.lang.Object {
            value: number;
            offset: number;
            count: number;
        }
        interface Thread extends java.lang.Object {
            pid: number;
            priority: number;
            nativeAlive: boolean;
        }
        interface Exception extends java.lang.Object {
            message: string;
        }
        interface InstantiationException extends java.lang.Exception {
        }
        interface IllegalArgumentException extends java.lang.Exception {
        }
        interface IllegalStateException extends java.lang.Exception {
        }
        interface NullPointerException extends java.lang.Exception {
        }
        interface RuntimeException extends java.lang.Exception {
        }
        interface IndexOutOfBoundsException extends java.lang.Exception {
        }
        interface ArrayIndexOutOfBoundsException extends java.lang.Exception {
        }
        interface StringIndexOutOfBoundsException extends java.lang.Exception {
        }
        interface ArrayStoreException extends java.lang.Exception {
        }
        interface IllegalMonitorStateException extends java.lang.Exception {
        }
        interface ClassCastException extends java.lang.Exception {
        }
        interface NegativeArraySizeException extends java.lang.Exception {
        }
        interface ArithmeticException extends java.lang.Exception {
        }
        interface ClassNotFoundException extends java.lang.Exception {
        }
        interface SecurityException extends java.lang.Exception {
        }
        interface IllegalThreadStateException extends java.lang.Exception {
        }
    }
    module java.lang.ref {
        interface Reference extends java.lang.Object {
        }
        interface WeakReference extends java.lang.ref.Reference {
            holder: number;
        }
    }
    module java.io {
        interface IOException extends java.lang.Exception {
        }
        interface UTFDataFormatException extends java.lang.Exception {
        }
        interface UnsupportedEncodingException extends java.lang.Exception {
        }
        interface OutputStream extends java.lang.Object {
        }
        interface ByteArrayOutputStream extends OutputStream {
            count: number;
            buf: Int8Array;
        }
        interface Writer extends java.lang.Object {
        }
    }
    module javax.microedition.media {
        interface MediaException extends java.lang.Exception {
        }
    }
    module com.sun.cldc.isolate {
        interface Isolate extends java.lang.Object {
            _id: number;
            _mainArgs: java.lang.String[];
            _mainClass: number;
            _priority: number;
        }
    }
    module com.sun.cldc.i18n {
        interface StreamWriter extends java.io.Writer {
        }
    }
    module com.sun.cldc.i18n.j2me {
        interface UTF_8_Writer extends com.sun.cldc.i18n.StreamWriter {
            pendingSurrogate: number;
        }
    }
    module javax.microedition.lcdui {
        interface Graphics extends java.lang.Object {
        }
        interface ImageData extends java.lang.Object {
            width: number;
            height: number;
            isMutable: boolean;
        }
        interface Image extends java.lang.Object {
            width: number;
            height: number;
            imageData: javax.microedition.lcdui.ImageData;
        }
    }
    module com.nokia.mid.ui {
        interface DirectGraphicsImp extends java.lang.Object {
            graphics: javax.microedition.lcdui.Graphics;
        }
    }
    module com.sun.midp.events {
        interface Event {
            type: number;
            next: com.sun.midp.events.Event;
        }
        interface NativeEvent extends com.sun.midp.events.Event {
            intParam1: number;
            intParam2: number;
            intParam3: number;
            intParam4: number;
            intParam5: number;
            intParam6: number;
            intParam7: number;
            intParam8: number;
            intParam9: number;
            intParam10: number;
            intParam11: number;
            intParam12: number;
            intParam13: number;
            intParam14: number;
            intParam15: number;
            intParam16: number;
            floatParam1: number;
            stringParam1: java.lang.String;
            stringParam2: java.lang.String;
            stringParam3: java.lang.String;
            stringParam4: java.lang.String;
            stringParam5: java.lang.String;
            stringParam6: java.lang.String;
        }
    }
    module com.sun.j2me.pim {
        interface PIMFieldDescriptor {
            field: number;
            dataType: number;
            maxValues: number;
        }
    }
}
/**
 * Asm.js native module declaration, this is defined by lib/native.js
 */
declare var ASM: any;
declare var Native: any;
/**
 * Asm.js heap buffer and views.
 */
declare var buffer: any;
declare var i8: Int8Array;
declare var u8: Uint8Array;
declare var i16: Int16Array;
declare var u16: Uint16Array;
declare var i32: Int32Array;
declare var u32: Uint32Array;
declare var f32: Float32Array;
declare var f64: Float64Array;
declare var aliasedI32: Int32Array;
declare var aliasedF32: Float32Array;
declare var aliasedF64: Float64Array;
declare module J2ME {
    function asyncImplOld(returnKind: string, promise: Promise<any>, cleanup?: Function): void;
    /**
     * Suspends the execution of the current thread and resumes it later once the specified
     * |promise| is fulfilled.
     *
     * |onFulfilled| is called with one or two arguments |l| and |h|. |l| can be any
     * value, while |h| can only ever be the high bits of a long value.
     *
     * |onRejected| is called with a java.lang.Exception object.
     */
    function asyncImpl(returnKind: Kind, promise: Promise<any>, cleanup?: Function): void;
}
declare module J2ME {
    /**
     * The closest floating-point representation to this long value.
     */
    function longToNumber(l: number, h: number): number;
    function returnLongValue(v: number): any;
}
declare module J2ME {
    /** @const */ var MAX_PRIORITY: number;
    /** @const */ var MIN_PRIORITY: number;
    /** @const */ var NORMAL_PRIORITY: number;
    /** @const */ var ISOLATE_MIN_PRIORITY: number;
    /** @const */ var ISOLATE_NORM_PRIORITY: number;
    /** @const */ var ISOLATE_MAX_PRIORITY: number;
    /**
     * Number of preemption checks thus far.
     */
    var preemptionCount: number;
    /**
     * Used to block preemptions from happening during code that can't handle them.
     */
    var preemptionLockLevel: number;
    /**
     * The scheduler tracks the amount of time(virtualRuntime) that each thread has had to execute
     * and tries to always execute the thread that has had least amount of time to run next.
     * For higher priority threads the virtual runtime is increased at a slower rate to give them
     * more time to be the the front of the queue and vice versa for low priority threads. To allow
     * the event loop a turn there is an overall MAX_WINDOW_EXECUTION_TIME that if reached will yield
     * all the threads and schedule them to resume on a setTimeout. This allows us to run up to
     * MAX_WINDOW_EXECUTION_TIME/PREEMPTION_INTERVAL threads per execution window.
     */
    class Scheduler {
        static enqueue(ctx: Context, directExecution?: boolean): void;
        private static processRunningQueue(directExecution?);
        private static updateMinVirtualRuntime();
        private static updateCurrentRuntime();
        static shouldPreempt(): boolean;
    }
}
declare var Shumway: any;
declare var profiling: any;
interface Array<T> {
    push2: (value) => void;
    pop2: () => any;
    pushKind: (kind: J2ME.Kind, value) => void;
    popKind: (kind: J2ME.Kind) => any;
    read: (i) => any;
}
declare module J2ME {
    enum WriterFlags {
        None = 0,
        Trace = 1,
        Link = 2,
        Init = 4,
        Perf = 8,
        Load = 16,
        JIT = 32,
        Code = 64,
        Thread = 128,
        TraceStack = 256,
        All = 511,
    }
    /**
     * Toggle VM tracing here.
     */
    var writers: WriterFlags;
    var CLASSES: ClassRegistry;
    class JVM {
        constructor();
        private createIsolateCtx();
        startIsolate0(className: string, args: string[]): void;
        startIsolate(isolateAddr: number): void;
    }
    class Context {
        runtime: Runtime;
        private static _nextId;
        private static _colors;
        private static writer;
        id: number;
        priority: number;
        /**
         * Whether or not the context is currently paused.  The profiler uses this
         * to distinguish execution time from paused time in an async method.
         */
        paused: boolean;
        lockTimeout: number;
        lockLevel: number;
        nativeThread: Thread;
        threadData: Int32Array;
        writer: IndentingWriter;
        methodTimeline: any;
        virtualRuntime: number;
        constructor(runtime: Runtime);
        threadAddress: number;
        static color(id: any): any;
        static currentContextPrefix(): string;
        /**
         * Sets global writers. Uncomment these if you want to see trace output.
         */
        static setWriters(writer: IndentingWriter): void;
        kill(): void;
        executeMethod(methodInfo: MethodInfo): any;
        createException(className: string, message?: string): java.lang.Object;
        setAsCurrentContext(): void;
        clearCurrentContext(): void;
        start(): void;
        execute(): void;
        resume(): void;
        block(lock: Lock, queue: any, lockLevel: number): void;
        unblock(lock: Lock, queue: any, notifyAll: boolean): void;
        wakeup(lock: Lock): void;
        monitorEnter(lock: Lock): void;
        monitorExit(lock: Lock): void;
        wait(objectAddr: number, timeout: number): void;
        notify(objectAddr: number, notifyAll: boolean): void;
        bailout(bailoutFrameAddress: number): void;
        pauseMethodTimeline(): void;
        resumeMethodTimeline(): void;
        /**
         * Re-enters all the frames that are currently on the stack so the full stack
         * trace shows up in the profiler.
         */
        restartMethodTimeline(): void;
        enterMethodTimeline(key: string, methodType: MethodType): void;
        leaveMethodTimeline(key: string, methodType: MethodType): void;
    }
}
declare var Context: typeof J2ME.Context;
declare var JVM: typeof J2ME.JVM;
declare function countTimeline(message: string, object?: Object): void;
declare function enterTimeline(message: string): void;
declare function leaveTimeline(message?: string): void;
declare module J2ME {
    class CompilerBailout {
        message: string;
        constructor(message: string);
        toString(): string;
    }
}
declare module J2ME {
    import Bytecodes = Bytecode.Bytecodes;
    var yieldCounter: any;
    var yieldGraph: any;
    const enum YieldReason {
        None = 0,
        Root = 1,
        Synchronized = 2,
        MonitorEnterExit = 3,
        Virtual = 4,
        Cycle = 5,
        Yield = 6,
        Likely = 7,
    }
    function getYieldReasonName(yieldReason: YieldReason): string;
    /**
     * Root set of methods that can yield. Keep this up to date or else the compiler will not generate yield code
     * at the right spots.
     */
    var yieldMap: {
        "com/sun/midp/lcdui/DisplayDevice.refresh0.(IIIIII)V": YieldReason;
        "com/sun/midp/main/MIDletSuiteUtils.vmBeginStartUp.(I)V": YieldReason;
        "com/sun/midp/lcdui/DisplayDevice.gainedForeground0.(II)V": YieldReason;
        "com/sun/cdc/io/j2me/file/DefaultFileHandler.openForRead.()V": YieldReason;
        "com/sun/cdc/io/j2me/file/DefaultFileHandler.openForWrite.()V": YieldReason;
        "com/sun/cdc/io/j2me/file/DefaultFileHandler.write.([BII)I": YieldReason;
        "java/lang/Thread.sleep.(J)V": YieldReason;
        "com/sun/cldc/isolate/Isolate.waitStatus.(I)V": YieldReason;
        "com/sun/j2me/location/PlatformLocationProvider.waitForNewLocation.(IJ)Z": YieldReason;
        "com/sun/javame/sensor/NativeChannel.doMeasureData.(II)[B": YieldReason;
        "com/sun/midp/util/isolate/InterIsolateMutex.lock0.(I)V": YieldReason;
        "com/sun/midp/events/NativeEventMonitor.waitForNativeEvent.(Lcom/sun/midp/events/NativeEvent;)I": YieldReason;
        "com/sun/midp/io/j2me/push/ConnectionRegistry.poll0.(J)I": YieldReason;
        "com/sun/midp/rms/RecordStoreFile.openRecordStoreFile.(Ljava/lang/String;Ljava/lang/String;I)I": YieldReason;
        "com/sun/midp/io/j2me/storage/RandomAccessStream.open.(Ljava/lang/String;I)I": YieldReason;
        "javax/microedition/lcdui/ImageDataFactory.createImmutableImageDecodeImage.(Ljavax/microedition/lcdui/ImageData;[BII)V": YieldReason;
        "com/nokia/mid/ui/TextEditorThread.getNextDirtyEditor.()Lcom/nokia/mid/ui/TextEditor;": YieldReason;
        "com/nokia/mid/ui/TextEditor.setFocus.(Z)V": YieldReason;
        "com/nokia/mid/ui/VKVisibilityNotificationRunnable.sleepUntilVKVisibilityChange.()Z": YieldReason;
        "org/mozilla/io/LocalMsgConnection.init.(Ljava/lang/String;)V": YieldReason;
        "org/mozilla/io/LocalMsgConnection.receiveData.([B)I": YieldReason;
        "org/mozilla/io/LocalMsgConnection.waitConnection.()V": YieldReason;
        "com/sun/mmedia/DirectPlayer.nGetDuration.(I)I": YieldReason;
        "com/sun/mmedia/DirectPlayer.nGetMediaTime.(I)I": YieldReason;
        "com/sun/mmedia/PlayerImpl.nRealize.(ILjava/lang/String;)Z": YieldReason;
        "com/sun/mmedia/DirectRecord.nPause.(I)I": YieldReason;
        "com/sun/mmedia/DirectRecord.nStop.(I)I": YieldReason;
        "com/sun/mmedia/DirectRecord.nClose.(I)I": YieldReason;
        "com/sun/mmedia/DirectRecord.nStart.(I)I": YieldReason;
        "com/sun/midp/io/j2me/socket/Protocol.open0.([BI)V": YieldReason;
        "com/sun/midp/io/j2me/socket/Protocol.read0.([BII)I": YieldReason;
        "com/sun/midp/io/j2me/socket/Protocol.write0.([BII)I": YieldReason;
        "com/sun/midp/io/j2me/socket/Protocol.close0.()V": YieldReason;
        "com/sun/midp/io/j2me/sms/Protocol.receive0.(IIILcom/sun/midp/io/j2me/sms/Protocol$SMSPacket;)I": YieldReason;
        "com/sun/midp/io/j2me/sms/Protocol.send0.(IILjava/lang/String;II[B)I": YieldReason;
        "com/sun/j2me/pim/PIMProxy.getNextItemDescription0.(I[I)Z": YieldReason;
        "java/lang/Object.wait.(J)V": YieldReason;
        "java/lang/Class.invoke_clinit.()V": YieldReason;
        "java/lang/Thread.yield.()V": YieldReason;
        "java/lang/Thread.start0.()V": YieldReason;
        "java/lang/Class.forName0.(Ljava/lang/String;)V": YieldReason;
        "java/lang/Class.newInstance1.(Ljava/lang/Object;)V": YieldReason;
        "java/lang/Runtime.gc.()V": YieldReason;
        "gnu/testlet/vm/NativeTest.throwExceptionAfterPause.()V": YieldReason;
        "gnu/testlet/vm/NativeTest.returnAfterPause.()I": YieldReason;
        "gnu/testlet/vm/NativeTest.dumbPipe.()Z": YieldReason;
        "gnu/testlet/TestHarness.getNumDifferingPixels.(Ljava/lang/String;)I": YieldReason;
        "org/mozilla/MemorySampler.sampleMemory.(Ljava/lang/String;)V": YieldReason;
        "org/mozilla/Test.callAsyncNative.()V": YieldReason;
        "javax/wireless/messaging/SendSMSTest.getNumber.()Ljava/lang/String;": YieldReason;
        "javax/wireless/messaging/SendSMSTest.getBody.()Ljava/lang/String;": YieldReason;
    };
    var yieldVirtualMap: {};
    var noPreemptMap: {
        "java/lang/Class.initialize.()V": boolean;
    };
    function isFinalClass(classInfo: ClassInfo): boolean;
    function isFinalMethod(methodInfo: MethodInfo): boolean;
    function gatherCallees(callees: MethodInfo[], classInfo: ClassInfo, methodInfo: MethodInfo): void;
    function isStaticallyBound(op: Bytecodes, methodInfo: MethodInfo): boolean;
    function traceYieldGraph(writer: IndentingWriter): void;
    function canStaticInitializerYield(classInfo: ClassInfo): YieldReason;
    function canYield(methodInfo: MethodInfo): YieldReason;
}
declare module J2ME {
    import Bytecodes = Bytecode.Bytecodes;
    import Condition = Bytecode.Condition;
    import BytecodeStream = Bytecode.BytecodeStream;
    import Block = Bytecode.Block;
    interface Relooper {
        addBlock(text: string, branchVar?: string): number;
        addBranch(from: number, to: number, condition?: string, code?: string): any;
        render(entry: number): string;
        init(): string;
    }
    var baselineCounter: any;
    /**
     * Emits array bounds checks. Although this is necessary for correctness, most
     * applications work without them.
     */
    var emitCheckArrayBounds: boolean;
    /**
     * Inline calls to runtime methods whenever possible.
     */
    var inlineRuntimeCalls: boolean;
    /**
     * Emits array store type checks. Although this is necessary for correctness,
     * most applications work without them.
     */
    var emitCheckArrayStore: boolean;
    /**
     * Emits preemption checks for methods that already yield.
     */
    var emitCheckPreemption: boolean;
    function baselineCompileMethod(methodInfo: MethodInfo, target: CompilationTarget): CompiledMethodInfo;
    class BaselineCompiler {
        sp: number;
        pc: number;
        private target;
        private bodyEmitter;
        private blockEmitter;
        private blockBodies;
        private blockMap;
        private methodInfo;
        private parameters;
        private hasHandlers;
        private hasMonitorEnter;
        private blockStackHeightMap;
        private initializedClasses;
        private referencedClasses;
        private variables;
        private lockObject;
        private hasOSREntryPoint;
        private entryBlock;
        private isPrivileged;
        static localNames: string[];
        /**
         * Make sure that none of these shadow global names, like "U" and "O".
         */
        static stackNames: string[];
        /**
         * Indicates whether a unwind throw was emitted.
         */
        private hasUnwindThrow;
        constructor(methodInfo: MethodInfo, target: CompilationTarget);
        compile(): CompiledMethodInfo;
        needsVariable(name: string, value?: string): void;
        setSuccessorsBlockStackHeight(block: Block, sp: number): void;
        emitBody(): void;
        private emitExceptionHandler(emitter, handler);
        /**
         * Resets block level optimization state.
         */
        resetOptimizationState(): void;
        emitBlockBody(stream: BytecodeStream, block: Block): void;
        private emitPrologue();
        private emitEntryPoints();
        lookupClass(cpi: number): ClassInfo;
        classInfoSymbol(classInfo: ClassInfo): string;
        classInfoObject(classInfo: ClassInfo): string;
        lookupMethod(cpi: number, opcode: Bytecodes, isStatic: boolean): MethodInfo;
        methodInfoSymbol(methodInfo: MethodInfo): string;
        lookupField(cpi: number, opcode: Bytecodes, isStatic: boolean): FieldInfo;
        getStackName(i: number): string;
        getStack(i: number): string;
        getLocalName(i: number): string;
        getLocal(i: number): string;
        emitLoadLocal(kind: Kind, i: number): void;
        emitStoreLocal(kind: Kind, i: number): void;
        peekAny(): string;
        peek(kind: Kind): string;
        popAny(): string;
        emitPopTemporaries(n: number): void;
        emitPushTemporary(...indices: number[]): void;
        pop(kind: J2ME.Kind): string;
        popSlot(): string;
        emitPushAny(v: any): void;
        emitPushBits(kind: Kind, v: number): void;
        emitPushInt(v: number): void;
        emitPushFloat(v: number): void;
        emitPushDouble(v: number): void;
        emitPushLongBits(l: number, h: number): void;
        emitPush(kind: Kind, v: string): void;
        emitReturn(kind: Kind): void;
        emitGetField(fieldInfo: FieldInfo, isStatic: boolean): void;
        emitPutField(fieldInfo: FieldInfo, isStatic: boolean): void;
        setBlockStackHeight(pc: number, height: number): void;
        emitIf(block: Block, stream: BytecodeStream, predicate: string): void;
        emitIfNull(block: Block, stream: BytecodeStream, condition: Condition): void;
        emitIfSame(block: Block, stream: BytecodeStream, kind: Kind, condition: Condition): void;
        emitIfZero(block: Block, stream: BytecodeStream, condition: Condition): void;
        runtimeClass(classInfo: ClassInfo): string;
        runtimeClassObject(classInfo: ClassInfo): string;
        emitClassInitializationCheck(classInfo: ClassInfo): void;
        emitInvoke(methodInfo: MethodInfo, opcode: Bytecodes, nextPC: number): void;
        emitNegativeArraySizeCheck(length: string): void;
        emitBoundsCheck(array: string, index: string): void;
        emitArrayStoreCheck(array: string, value: string): void;
        emitStoreIndexed(kind: Kind): void;
        emitLoadIndexed(kind: Kind): void;
        emitIncrement(stream: BytecodeStream): void;
        emitGoto(block: Block, stream: BytecodeStream): void;
        emitLoadConstant(index: number): void;
        emitThrow(pc: number): void;
        emitNewInstance(cpi: number): void;
        emitNewTypeArray(typeCode: number): void;
        emitCheckCast(cpi: number): void;
        emitInstanceOf(cpi: number): void;
        emitNullPointerCheck(address: any): void;
        emitArrayLength(): void;
        emitNewObjectArray(cpi: number): void;
        emitNewMultiObjectArray(cpi: number, stream: BytecodeStream): void;
        private emitUnwind(emitter, pc, forceInline?);
        private emitBailout(emitter, pc, sp, stackCount);
        emitNoUnwindAssertion(): void;
        emitUndefinedReturnAssertion(): void;
        private emitMonitorEnter(emitter, nextPC, object);
        private emitPreemptionCheck(emitter);
        private emitMonitorExit(emitter, object);
        emitStackOp(opcode: Bytecodes): void;
        emitDivideByZeroCheck(kind: Kind, l: string, h: string): void;
        emitArithmeticOp(kind: Kind, opcode: Bytecodes, canTrap: boolean): void;
        emitNegateOp(kind: Kind, opcode: Bytecodes): void;
        emitShiftOp(kind: Kind, opcode: Bytecodes): void;
        emitLogicOp(kind: Kind, opcode: Bytecodes): void;
        emitConvertOp(from: Kind, to: Kind, opcode: Bytecodes): void;
        emitCompareOp(kind: Kind, isLessThan: boolean): void;
        getBlockIndex(pc: number): number;
        getBlock(pc: number): Block;
        emitTableSwitch(block: Block, stream: BytecodeStream): void;
        emitLookupSwitch(block: Block, stream: BytecodeStream): void;
        emitBytecode(stream: BytecodeStream, block: Block): void;
    }
}
declare module J2ME {
    class Emitter {
        writer: IndentingWriter;
        closure: boolean;
        debugInfo: boolean;
        klassHeaderOnly: boolean;
        constructor(writer: IndentingWriter, closure: boolean, debugInfo: boolean, klassHeaderOnly?: boolean);
    }
    const enum CompilationTarget {
        Runtime = 0,
        Static = 1,
    }
    function emitMethodMetaData(emitter: Emitter, methodInfo: MethodInfo, compiledMethodInfo: CompiledMethodInfo): void;
    function emitReferencedSymbols(emitter: Emitter, classInfo: ClassInfo, compiledMethods: CompiledMethodInfo[]): void;
    class CompiledMethodInfo {
        args: string[];
        body: string;
        referencedClasses: ClassInfo[];
        onStackReplacementEntryPoints: number[];
        constructor(args: string[], body: string, referencedClasses: ClassInfo[], onStackReplacementEntryPoints?: number[]);
    }
    function compileMethod(methodInfo: MethodInfo, ctx: Context, target: CompilationTarget): CompiledMethodInfo;
    function compile(jvm: any, jarFiles: Map<string, any>, jarFilter: (jarFile: string) => boolean, classFilter: (classInfo: ClassInfo) => boolean, methodFilterList: string[], fileFilter: string, debugInfo: boolean): void;
}
